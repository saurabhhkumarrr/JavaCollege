//package Unit_1; //user defined package

public class HellowWorld // class name is same as the file name.
{
  public static void main(String[] args)// Syntax of the main method
  {
    System.out.println("Hello Java");// Method to print string on console.
  }
}