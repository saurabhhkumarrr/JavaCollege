//import Unit_3.Animal;

class Animal{
 String color;
void eat(){
    System.out.println("Eat");
}    

class Mammal extends Animal{
    int legs;
}
class Dog extends Mammal{
    String breed;
}
}
public static void main(String args[]){
    Dog tommy =  new Dog();
    tommy.eat();
    tommy.legs=4;
    System.out.println(tommy.legs);
}
}