
public class ArrayImplementation {
    public static void main(String[] args) {
        // Declaration and initialization of an array of integers
        int[] intArray = {1, 2, 3, 4, 5};

        // Accessing elements of the array using index
        System.out.println("Elements of the array:");
        for (int i = 0; i < intArray.length; i++) {
            System.out.println("Element at index " + i + ": " + intArray[i]);
        }

        // Updating an element of the array
        intArray[2] = 10;

        // Accessing the updated element
        System.out.println("\nAfter updating:");
        System.out.println("Element at index 2: " + intArray[2]);

        // Declaration and initialization of an array of strings
        String[] strArray = {"apple", "banana", "orange"};

        // Accessing elements of the string array using enhanced for loop
        System.out.println("\nElements of the string array:");
        for (String fruit : strArray) {
            System.out.println(fruit);
        }
    }
}