import java.util.*;
public class ConstructorOverlaoding 
{
      int sum(int a,int b)
     {
         return a + b;
     }
     int sum(int a,int b,int c)
     {
         return a + b + c;
     }
     float sum(float a ,int b)
     {
         return a + b;
     } 
     public static void main(String[] args)
     {
         MethodOverloading MO = new MethodOverloading();
         System.out.println("Sum method called with two numbers:" + MO.sum(45,67));
         System.out.println("Sum method called with three numbers:" + MO.sum(123,456,789));
     }
}