class Student {
    String name;
    int rollNumber;

    // Default constructor
    public Student() {
        name = "Unknown";
        rollNumber = 0;
    }

    // Parameterized constructor
    public Student(String name, int rollNumber) {
        this.name = name;
        this.rollNumber = rollNumber;
    }

    public void displayInfo() {
        System.out.println("Name: " + name);
        System.out.println("Roll Number: " + rollNumber);
    }

    public static void main(String[] args) {
        // Creating objects using default constructor
        Student student1 = new Student();
        System.out.println("Default Constructor Output:");
        student1.displayInfo();
        
        System.out.println();

        // Creating objects using parameterized constructor
        Student student2 = new Student("Alice", 101);
        System.out.println("Parameterized Constructor Output:");
        student2.displayInfo();
    }
}
