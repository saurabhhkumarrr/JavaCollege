//package Java4th.Unit4;
import java.util.StringTokenizer;
public class Tokenizer 
{
/*The java.util.StringTokenizer class allows you to break a String into tokens. 
  It is a very simple way to break a String into smaller tokens. It is a legacy class of Java.
  It cannot differentiate numbers, quoted strings, identifiers etc like StreamTokenizer class.
  In the StringTokenizer class,the delimiters can be provided at the time of creation 
  or one by one to the tokens.*/
  public static void main(String args[])
  {  
   StringTokenizer st = new StringTokenizer("Programming in Java"," ");  
     while (st.hasMoreTokens()) 
     {  
         System.out.println(st.nextToken());  
     } 
     StringTokenizer st1 = new StringTokenizer("Programming_in_Java");
     System.out.println("Next token is : " + st1.nextToken("_"));
     System.out.println("Next token is : " + st1.nextToken("_"));
     System.out.println("Next token is : " + st1.nextToken("_"));
     System.out.println(st.countTokens());
     System.out.println(st1.countTokens());
  }
}
