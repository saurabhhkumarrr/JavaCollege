//package Java4th.Unit4;
public class DynamicArrays 
{
    /*A dynamic array is variable length linear data structure.(1 dimensional array).
    A dynamic array will grow automatically in size when we try to insert new element
    in the array and there is no more space.It allows us to insert and delete elements.
    Dymanic array is stored and created in heap area at runtime.Arraylist is one of 
    the implementations of dynamic array.
    */
    private int[] arrays ;// private instance variable array
    private int count;//privtae instance variable count
    private int arraySize;//private instance variable arraySize
    public DynamicArrays()
    {
        arrays = new int[1];
        count = 0;
        arraySize = 1;
    }
    public void insertElement(int a)
    {
        if(count == arraySize)
        {
            increaseSize();//method to double the size of current dynamic array
        }
        arrays[count] = a;
        count++; 
    }
    public void increaseSize()
    {
        int[] temp = null;
        if(count == arraySize) 
        {
            temp = new int[arraySize*2];
        }
        for (int i = 0; i < arraySize; i++)
        {
            temp[i] = arrays[i];
        }
        arrays = temp;
        arraySize *= 2;
    }
    public void addElementAt(int index,int a) //index = 5 a = 100
    {
        if(count == arraySize) //count = 8 arraySize = 8
        {
            increaseSize();
        }
        //[10,20,30,40,50,60,70,80,,,,,,,,]
        for(int i = count-1;i >= index;i--) //i =4 to i =5
        {
            arrays[i+1] = arrays[i];
            
        }
        //After looping arrays array looks like this:[10,20,30,40,50,60,60,70,80,,,,,,]
        arrays[index] = a;
        //After this statement arrays array looks like this:[10,20,30,40,50,100,60,70,80,,,,,,]
        count++;
    }
    public static void main(String[] args)
    {
        DynamicArrays da = new DynamicArrays();
        da.insertElement(10);
        da.insertElement(20);
        /* arrays array looks like this after inserting 2 elements:[10,20]
           count = 2 arraySize = 2;  
        */
        da.insertElement(30);
        /* arrays array looks like this after inserting 3 elements:[10,20,30, ]
           count = 3 arraySize = 4;  
        */
        da.insertElement(40);
        /* arrays array looks like this after inserting 4 elements:[10,20,30,40 ]
           count = 4 arraySize = 4;  
        */
        da.insertElement(50);
        /* arrays array looks like this after inserting 5 elements:[10,20,30,40,50, , , ]
           count = 5 arraySize = 8;  
        */
        da.insertElement(60);
        /* arrays array looks like this after inserting 6 elements:[10,20,30,40,50,60, , ]
           count = 6 arraySize = 8;  
        */
        da.insertElement(70);
        /* arrays array looks like this after inserting 7 elements:[10,20,30,40,50,60,70 , ]
           count = 7 arraySize = 8;  
        */
        da.insertElement(80);
        /* arrays array looks like this after inserting 8 elements:[10,20,30,40,50,60,70,80]
           count = 8 arraySize = 8;  
        */
        da.addElementAt(5,100);
        /* arrays array looks like this after inserting 9 elements:[10,20,30,40,50,100,60,70,80,0,0,0,0,0,0,0]
           count = 9 arraySize = 16;  
        */
        da.addElementAt(15, 1000);
        /* arrays array looks like this after inserting 10 elements:[10,20,30,40,50,100,60,70,80,0,0,0,0,0,0,1000]
           count = 10 arraySize = 16 ;  
        */
        System.out.print("Elements of the dynamic array are:");
        for (int i = 0;i < da.arraySize;i++)
        {
            System.out.print(da.arrays[i] + " ");
        }
        System.out.println();
        System.out.println("Size of the array:" + da.arraySize);
        System.out.println("No of elements in the dynamic array:" + da.count);
    }
}
