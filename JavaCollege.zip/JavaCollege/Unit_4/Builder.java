//package Java4th.Unit4;
public class Builder 
{
    /*
    StringBuilder is non-synchronized(no thread safety) 
    It means two threads can call the methods of StringBuilder simultaneously.
    This class is more efficient than String Buffer class.It is available since JDK 1.5.
    */
     public static void main(String[] args)
     {  
        StringBuilder builder=new StringBuilder("Java"); 
        System.out.println(builder);
        builder.append(" Language");  
        System.out.println(builder);  
     }
}
