//package Java4th.Unit4;
public class StringExample {
    public static void main(String[] args)
    {
        String a="ABC";
        String b="ABC";
        String c=new String("ABC");//String object is actually created here.
        System.out.println(a==c);
        System.out.println(c.equals(b));
        System.out.println(c.length());
        System.out.println(c.toLowerCase());
        String script="We're gonna need a bigger chopper";
        System.out.println(script.indexOf("gonna"));
        System.out.println(script.substring(2,16));
        System.out.println(script.contains("Gonna need"));
        String s="Hello";
        s.concat(" World");
        System.out.print(s);
       /* String w =s.concat(" World");
        System.out.println(s);//immutable new string object is created here.
        System.out.println(s==w);
*/
       }
    }
