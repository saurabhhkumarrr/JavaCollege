//package Java4th.Unit4;

import java.util.Arrays;//this Arrays class has a sort method which sorts the array given to it as argument.

public class Array {
 /*An array is a group of related variables that share the same type. Any type of information that
can be stored as a variable can become the item stored in an array. Arrays can be used to keep
track of more sophisticated types of information than a single variable, but they are almost as
easy to create and manipulate as a variable.
*/
    
    public static void main(String[] args)
    {
        /*    col0  col1  col2
       row 0 [ 00    01    02]    [ 1 2 3]
       row 1 [ 10    11    12]    [ 4 5 6]
       row 2 [ 20    21    22]    
        */
        
       int[][] matrix=new int[2][3]; // array object named matrix containing 6 elements.
        matrix[1][2]=12;
        int[][] mat={ {1,2,3}, {4,5,6} };
        System.out.println(mat.length);
        
        for(int i=0;i<mat.length;i++)  //mat array's length = 6 
                        //2           
        {
            for(int j=0;j<mat[i].length;j++)
                           //3
            {
            System.out.print(mat[i][j]+" ");
            }
        }
        System.out.println();
        int[] list=new int[5];// creating array with new keyword.list object 
        int[] list1={1,2,3,4,5};// creating array like a variable.list1.
        list[0]=10;
        String[] names=new String[5];//names is an array object of 5 string objetcs.
        String[] names1 = {"ABC","5678","ergfgsf","485yyiyfh@"};
             System.out.println(names1[4].charAt(0));
             
        names[0]="2398yiregukhkhvkdfhvk";
        names[1]="B";
        names[2]="C";
        names[3]="D";
        names[4]="E";
        for(int i=0;i<names.length;i++)
        {
            System.out.println(names[i]);
        }

       String sentence="Programming in Java";
        char[] name=sentence.toCharArray();
        for(int dex=0;dex<name.length;dex++)
        {
            if(name[dex]==' ')
                System.out.print(".");
            else
                System.out.print(name[dex]);
        }
        System.out.println();
        String[] n={"Vinod","Ajay","Vijay","Maneesh","Graphics","String"};
        Arrays.sort(n);
        for(int i=0;i<n.length;i++)
        {
            System.out.print(n[i]+" ");
        }

    }
    
    
}

