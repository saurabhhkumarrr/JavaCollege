//package Java4th.Unit4;

public class Arrays {
    public static void main(String[] args)
    {
        /*An array is a group of related variables that share the same type. 
          Any type of information that can be stored as a variable can 
          become the item stored in an array. Arrays can be used to keep
          track of more sophisticated types of information than a single variable, 
          but they are almost as easy to create and manipulate as a variable.
          Arrays can also store objects of a class.
        */
    
        int[] linearArray = {1,2,3,4,5,6,7,8,9,10};// single dimensional array
                     //index:0,1,2,3,4,5,6,7,8,9
        //System.out.println(linearArray[7]);
        for(int i = 0;i < linearArray.length;i++)
        {
            System.out.println("Element at index " + i + " is:" + linearArray[i]);
        }
        
        System.out.println();
        int [] linearArray1 = new int[10];//array object is created here using new keyword
        linearArray1[7] = 8;
        linearArray1[9] = 10;
        linearArray1[5] = 5;
        linearArray1[4] = 4;
        // System.out.println("Element at index =5 is:" + linearArray1[5]);
        
      int[][] twoD = {{1,2,3,4},{5,6,7,8,9},{10,11,12,13,14,15},{100,200,300,400,500,600,700}};
      int[][] twoD1 = new int[3][3];// 2D array object named twoD is created.
        //{{1,2,3},{4,5,6},{7,8,9}}
        twoD1[2][2] = 56;
     for(int i = 0;i < twoD.length;i++)
        {
            for(int j = 0;j < twoD[i].length;j++)
            {
             System.out.print(twoD[i][j] + " ");
            }
        }
     /* String[] name={"Java","is","still","the","best","OOP","language"};// name is an object which contains an array of string objects.
     System.out.println(name[2].charAt(0));
      System.out.println(name[5].charAt(1)); 
      for(int i = 0; i < name.length;i++)
      {
          System.out.println(name[i]);
      }
      String sentence = "Programming in Java";
      char[] sentence1 = sentence.toCharArray();
      sentence1[15]='Z';
      System.out.println(sentence1);*/
      
    }
}
