//package Java4th.Unit4;
public class Buffer {
/*StringBuffer is a peer class of String that provides much of the functionality 
  of strings. 
  String represents fixed-length, immutable character sequences while StringBuffer 
  represents growable and writable character sequences.
  StringBuffer may have characters and substrings inserted in the middle or 
  appended to the end. 
  It will automatically grow to make room for such additions and often  
  has more characters preallocated than are actually needed,to allow room for growth.
  StringBuffer is synchronized(safe thread). It means 
  two threads can't call the methods of StringBuffer class simultaneously.
  It is available since Java 1.0*/
    public static void main(String[] args)
    {
        StringBuffer S=new StringBuffer();//holds 16 elements by default
        StringBuffer S2=new StringBuffer(10);
        StringBuffer S3=new StringBuffer("Hello");
        S3.append(" World");
        System.out.println(S3);
        
        System.out.println(S3.length());
        S3.insert(5, " New");
        System.out.println(S3);
        System.out.println(S3.length());
        S3.reverse();
        System.out.println(S3);
        S3.append("ABCD");
        S2.append("EFGH");
        System.out.println(S2.capacity());
        System.out.println(S3.capacity());
        System.out.println(S.capacity());
        
    }
}
