public class SquareRootCalculator {
    public static void main(String[] args) {
        int durationSeconds = 10;
        int squareRootCount = calculateSquareRoots(durationSeconds);

        System.out.println("Square roots calculated in " + durationSeconds + " seconds: " + squareRootCount);
    }

    private static int calculateSquareRoots(int durationSeconds) {
        long startTime = System.currentTimeMillis();
        int squareRootCount = 0;

        while (System.currentTimeMillis() - startTime < durationSeconds * 1000L) {
            Math.sqrt(squareRootCount);
            squareRootCount++;
        }

        return squareRootCount;
    }
}