public class PrimeNumberBenchmark {
    public int generatePrimeNumbers(long timeLimitInMillis) {
        long startTime = System.nanoTime();
        long endTime = startTime + timeLimitInMillis * 1_000_000; // Convert time limit to nanoseconds
        int num = 2; // Starting from 2, the first prime number
        int numPrimes = 0;

        while (System.nanoTime() < endTime) {
            if (isPrime(num)) {
                numPrimes++;
            }
            num++;
        }

        return numPrimes; // Return the number of prime numbers generated
    }

    private boolean isPrime(int n) {
        if (n <= 1) {
            return false;
        }
        for (int i = 2; i <= Math.sqrt(n); i++) {
            if (n % i == 0) {
                return false;
            }
        }
        return true;
    }

    public static void main(String[] args) {
        System.out.print("Enter the time limit in seconds: ");
        java.util.Scanner sc = new java.util.Scanner(System.in);
        long timeLimitInSeconds = sc.nextLong();

        PrimeNumberBenchmark benchmark = new PrimeNumberBenchmark();
        int numPrimes = benchmark.generatePrimeNumbers(timeLimitInSeconds * 1000); // Convert seconds to milliseconds

        System.out.println("Number of prime numbers generated within " + timeLimitInSeconds + " seconds: " + numPrimes);
        sc.close();
    }
}