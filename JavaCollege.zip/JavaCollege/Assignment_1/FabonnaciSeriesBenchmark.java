/* this program will calculate the Fabonacci series  */

public class FabonnaciSeriesBenchmark {
    public static int fabonacci(long time) {
        long currTime = System.currentTimeMillis();
        long endTime = time * 1000 + currTime; // time(in sec) = sec*1_millseconds
        int first = 0, sec = 1, next = 0;
        int count = 0; // will track the no of iterations.
        while (currTime < endTime) {
            next = first + sec;
            first = sec;
            sec = next;
            count++;
            currTime = System.currentTimeMillis(); // updating current time at every Iteration
        }
        return count;
    }

    public static void main(String args[]) {
        System.out.print("Enter the time in seconds to be added : ");
        java.util.Scanner sc = new java.util.Scanner(System.in);
        long x = sc.nextLong();
        FabonnaciSeriesBenchmark fab = new FabonnaciSeriesBenchmark();
        long p = fab.fabonacci(x);
        System.out.print("No. of fabonnaci terms calculated in " + x + " sec = " + p);

    }
}
