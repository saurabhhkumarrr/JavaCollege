import java.util.ArrayList;
import java.util.Scanner;

public class ExtendedPythagoreanTripleBenchmark {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the time limit in milliseconds: ");
        long timeLimitInMillis = sc.nextLong();
        
        ExtendedPythagoreanTripleBenchmark benchmark = new ExtendedPythagoreanTripleBenchmark();
        TripleStats tripleStats = benchmark.findPythagoreanTriples(timeLimitInMillis);
        
        System.out.println("Number of Pythagorean triples found within " + timeLimitInMillis + " milliseconds: " + tripleStats.getCount());
        System.out.println("Average time per triple: " + tripleStats.getAverageTimePerTriple() + " milliseconds");
        System.out.println("Max triple found: " + tripleStats.getMaxTriple());
        System.out.println("Min triple found: " + tripleStats.getMinTriple());
        System.out.println("Distribution of triples by 'c' value: ");
        for (int c = 1; c <= 100; c++) {
            System.out.println("c = " + c + ": " + tripleStats.getTriplesByC(c));
        }
    }

    public TripleStats findPythagoreanTriples(long timeLimitInMillis) {
        long startTime = System.currentTimeMillis();
        long endTime = startTime + timeLimitInMillis;
        int count = 0;
        ArrayList<Triple> triples = new ArrayList<>();

        for (int c = 1; c <= 1000; c++) {
            for (int b = 1; b <= c; b++) {
                for (int a = 1; a <= b; a++) {
                    if (System.currentTimeMillis() >= endTime) {
                        return new TripleStats(count, triples);
                    }
                    if (isPythagoreanTriple(a, b, c)) {
                        count++;
                        triples.add(new Triple(a, b, c));
                    }
                }
            }
        }
        return new TripleStats(count, triples);
    }

    private boolean isPythagoreanTriple(int a, int b, int c) {
        return a * a + b * b == c * c;
    }

    private static class Triple {
        private final int a, b, c;

        public Triple(int a, int b, int c) {
            this.a = a;
            this.b = b;
            this.c = c;
        }

        @Override
        public String toString() {
            return "(" + a + ", " + b + ", " + c + ")";
        }
    }

    private static class TripleStats {
        private final int count;
        private final ArrayList<Triple> triples;

        public TripleStats(int count, ArrayList<Triple> triples) {
            this.count = count;
            this.triples = triples;
        }

        public int getCount() {
            return count;
        }

        public ArrayList<Triple> getTriples() {
            return triples;
        }

        public long getAverageTimePerTriple() {
            if (count == 0) {
                return 0;
            }
            long totalTime = triples.stream().mapToLong(triple -> triple.a + triple.b + triple.c).sum();
            return totalTime / count;
        }

        public Triple getMaxTriple() {
            return triples.stream().max((t1, t2) -> Integer.compare(t1.c, t2.c)).orElse(null);
        }

        public Triple getMinTriple() {
            return triples.stream().min((t1, t2) -> Integer.compare(t1.c, t2.c)).orElse(null);
        }

        public int getTriplesByC(int cValue) {
            return (int) triples.stream().filter(triple -> triple.c == cValue).count();
        }
    }
}