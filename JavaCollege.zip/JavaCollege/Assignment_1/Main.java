
public class Main
{
    public int count(long time)//10000
    {
        long currentTime = System.currentTimeMillis();//0
        long endTime = currentTime + time; //time= 10000 endtime=20000
        double square = 0;
        int index = 0;
        while(true)
        {
            square = Math.sqrt(square);
            index++;
            long now = System.currentTimeMillis();
            if(now > endTime)//10000<20000
            {
                return index;
            }
        }
    }
    public static void main(String[] args)
    {
        System.out.print("Enter the duration in seconds for which benchmark is to be run:");
        java.util.Scanner sc = new java.util.Scanner(System.in);
        long input = sc.nextLong();
        //in 1 second there are 1000 milliseconds
        Main B = new Main();
        System.out.println( B.count(input) + " loops in " + input + " seconds." );
        sc.close();
    }
}
