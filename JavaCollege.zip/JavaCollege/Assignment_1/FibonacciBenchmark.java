public class FibonacciBenchmark {
    public int calculateFibonacci(long timeLimitInMillis) {
        long startTime = System.nanoTime();
        long endTime = startTime + timeLimitInMillis * 1_000_000; // Convert time limit to nanoseconds
        int num1 = 0, num2 = 1, nextTerm = 0;
        int numTerms = 0;

        while (System.nanoTime() < endTime) {
            nextTerm = num1 + num2;
            num1 = num2;
            num2 = nextTerm;
            numTerms++;
        }

        return numTerms; // Return the number of terms in the Fibonacci series calculated
    }

    public static void main(String[] args) {
        System.out.print("Enter the time limit in seconds: ");
        java.util.Scanner sc = new java.util.Scanner(System.in);
        long timeLimitInSeconds = sc.nextLong();

        FibonacciBenchmark benchmark = new FibonacciBenchmark();
        int numTerms = benchmark.calculateFibonacci(timeLimitInSeconds * 1000); // Convert seconds to milliseconds

        System.out.println("Number of Fibonacci terms calculated within " + timeLimitInSeconds + " seconds: " + numTerms);
        sc.close();
    }
}