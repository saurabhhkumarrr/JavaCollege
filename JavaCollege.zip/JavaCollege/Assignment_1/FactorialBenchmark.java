public class FactorialBenchmark {
    public int calculateFactorials(long timeLimitInMillis) {
        long startTime = System.currentTimeMillis();
        long endTime = startTime + timeLimitInMillis * 1000; // Convert time limit to nanoseconds
        int num = 1;
        long factorial = 1;

        while (System.currentTimeMillis() < endTime) {
            factorial *= num;
            num++;
        }

        return num - 1; // Return the number of factorials calculated
    }

    public static void main(String[] args) {
        System.out.print("Enter the time limit in seconds: ");
        java.util.Scanner sc = new java.util.Scanner(System.in);
        long timeLimitInSeconds = sc.nextLong();

        FactorialBenchmark benchmark = new FactorialBenchmark();
        int numFactorials = benchmark.calculateFactorials(timeLimitInSeconds); // Convert seconds to milliseconds

        System.out.println("Number of factorials calculated within " + timeLimitInSeconds + " seconds: " + numFactorials);
        sc.close();
    }
}