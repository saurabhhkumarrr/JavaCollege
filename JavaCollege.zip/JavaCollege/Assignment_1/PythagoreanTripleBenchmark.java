import java.util.ArrayList;

public class PythagoreanTripleBenchmark {
    public int findPythagoreanTriples(long timeLimitInMillis) {
        long startTime = System.nanoTime();
        long endTime = startTime + timeLimitInMillis * 1_000_000; // Convert time limit to nanoseconds
        int a = 1, b = 1, c = 1;
        int count = 0;

        while (System.nanoTime() < endTime) {
            while (c <= 100) { // Define your range for the sides a, b, and c
                while (b <= c) {
                    while (a <= b) {
                        if (isPythagoreanTriple(a, b, c)) {
                            count++;
                        }
                        a++;
                    }
                    a = 1;
                    b++;
                }
                b = 1;
                c++;
            }
        }

        return count; // Return the number of Pythagorean triples found
    }

    private boolean isPythagoreanTriple(int a, int b, int c) {
        return a * a + b * b == c * c;
    }

    public static void main(String[] args) {
        System.out.print("Enter the time limit in seconds: ");
        java.util.Scanner sc = new java.util.Scanner(System.in);
        long timeLimitInSeconds = sc.nextLong();

        PythagoreanTripleBenchmark benchmark = new PythagoreanTripleBenchmark();
        int count = benchmark.findPythagoreanTriples(timeLimitInSeconds * 1000); // Convert seconds to milliseconds

        System.out.println("Number of Pythagorean triples found within " + timeLimitInSeconds + " seconds: " + count);
        sc.close();
    }
}