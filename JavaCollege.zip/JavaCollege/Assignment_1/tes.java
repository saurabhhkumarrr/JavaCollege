public class tes {
    public int count(long time)//10000
    {
        long currentTime = System.currentTimeMillis();//0
        long endTime = currentTime + time; //time= 10000 endtime=20000
        double square = 0;
        int count = 0;
        double sq=0;
        while(true)
        {
            sq = Math.sqrt(square);
            //square = Math.sqrt(square);: This line calculates the square root of the variable square and assigns the result back to square. It effectively keeps taking the square root of the previous result.
            /*Suppose we start with an initial value for square as 4.
1.First Iteration:------------
Math.sqrt(square) calculates the square root of 4, which is 2.This result (2) is then assigned back to square, so now square becomes 2.
At the end of the first iteration, square is 2.
2.Second Iteration:--------------
Math.sqrt(square) calculates the square root of 2, which is approximately 1.414.This result (1.414) is assigned back to square, so now square becomes 1.414.
At the end of the second iteration, square is 1.414.
3.Third Iteration:--------------
Math.sqrt(square) calculates the square root of 1.414, which is approximately 1.189. This result (1.189) is assigned back to square, so now square becomes 1.189.
At the end of the third iteration, square is 1.189. This process continues, with each iteration updating the value of square to be its square root, until the loop terminates based on the specified condition or time limit.
So, the line square = Math.sqrt(square); effectively updates the value of square to be the square root of its previous value in each iteration of the loop.*/         count++;
            sq++;
            long now = System.currentTimeMillis();
            if(now > endTime)//10000<20000
            {
                return count;
            }
        }
    }
    public static void main(String[] args)
    {
        System.out.print("Enter the duration in seconds for which benchmark is to be run:");
        java.util.Scanner sc = new java.util.Scanner(System.in);
        long input = sc.nextLong();
        //in 1 second there are 1000 milliseconds
        Benchmark B = new Benchmark();
        System.out.println( B.count(input) + " loops in " + input + " seconds." );
    }
}

