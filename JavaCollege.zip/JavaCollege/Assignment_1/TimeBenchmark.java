public class TimeBenchmark {
    public long measureTime(int n, int additionalSeconds) {
        long startTime = System.nanoTime();
        int sum = 0;
        for (int i = 1; i <= n; i++) {
            sum += i;
        }
        long endTime = System.nanoTime();

        // Add additional seconds
        try {
            Thread.sleep(additionalSeconds * 1000); // Convert seconds to milliseconds
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        return endTime - startTime;
    }

    public static void main(String[] args) {
        System.out.print("Enter the value of n to calculate sum from 1 to n: ");
        java.util.Scanner sc = new java.util.Scanner(System.in);
        int n = sc.nextInt();

       System.out.print("Enter the number of additional seconds: ");
        int additionalSeconds = sc.nextInt();

        TimeBenchmark benchmark = new TimeBenchmark();
        long elapsedTime = benchmark.measureTime(n, additionalSeconds);

        System.out.println("Time taken to calculate sum from 1 to " + n + " with additional " + additionalSeconds + " seconds: " + elapsedTime + " nanoseconds");
        sc.close();
    }
}