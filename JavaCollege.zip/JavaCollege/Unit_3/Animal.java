public class Animal 
{
    public static void main(String[] args)
       {
           Animal human1 = new Animal();// default constructor is called here.
           Animal human2 = new Animal();
           human1.height=100;
           human1.color="White";
           human1.tall();
           human1.tone();
           human1.sleep();
           human2.height=200;
           human2.color="Light";
           human2.tall();
           human2.tone();
           human2.run();
       }
    int height;// instance/object variable height
    String color; //instancAnimal()e/object variable color
   //both height and color are called attributes of the class Animal.
    //A java class is a template which is used to create objects.
   public void sleep() //instance method sleep()
   {
      System.out.println("Sleeping");
   }
   public void run() //instance method run()
   {
       System.out.println("Running");
   }
   public void tall()
   {
       System.out.println("I am "+ height +" cms tall");
   }
   public int getHeight() {
    return height;
}
public void setHeight(int height) {
    this.height = height;
}
public String getColor() {
    return color;
}
public void setColor(String color) {
    this.color = color;
}
void tone()
   {
       System.out.println("My color is "+ color);
   }
 }
