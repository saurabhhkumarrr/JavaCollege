
public class ConstructorOverlaoding 
{
    int age;  
    String name;
    char grade;
    public ConstructorOverlaoding(int age,char grade)// first constructor for this class.
    {
        this.age=age;
        this.grade=grade;
    }
    public ConstructorOverlaoding(char grade) // second constructor for this class.
    {
        this.grade=grade;
    }
    public ConstructorOverlaoding(int age) // third constructor for this class.
    {
        this.age=age;
    }
    public ConstructorOverlaoding(String name) // forth constructor for this class.
    {
        this.name = name;
    }
    public void displayName()
    {
        System.out.println("Name:" + name);
    }
    public void displayAge()
    {
        System.out.println("Age:" + age);
    }
    public void displayGrade()
    {
        System.out.println("Grade:" + grade);
    }
    public static void main(String[] args)
    {
        ConstructorOverlaoding student1 = new ConstructorOverlaoding(20,'A');
        student1.displayAge();
        student1.displayGrade();
        student1.displayName();
        System.out.println();
        ConstructorOverlaoding student2 = new ConstructorOverlaoding(19);
        student2.displayAge();
        student2.displayGrade();
        student2.displayName();
        System.out.println();
        ConstructorOverlaoding student3 = new ConstructorOverlaoding("Ankit Kumar");
        student3.displayAge();
        student3.displayGrade();
        student3.displayName();
        
    }
}
