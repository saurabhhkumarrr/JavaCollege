// 
//package Java4th.Unit3;
public class WrapperClass 
{
   /*Wrapper classes in java provide mechanisms to convert primitive datatypes into objects
   and vice versa.
    Example: Boolean class,Float class,Integer class etc.
    AutoBoxing:Conversion of primitive datatype into its corresponding wrapper class
    is called Autoboxing.Example:int to Integer class etc.
    Unboxing:Conversion of a wrapper class into its corresponding datatype is called Unboxing.
   */
    public static void main(String[] args)
    {
        /*
        int a = 100;
        Integer I = a;//Autoboxing
        System.out.println(I);
        Integer J = 1000;
        int b = J;//Unboxing
        System.out.println(b);
*/
        byte b = 126;
        short s = 2000;
        int i = 3000;
        long l = 4000;
        float f = 5000.03412F;
        double d = 7000.13451351345134;
        char c = 'a';
        boolean b1 = true;
        //Autoboxing from line no. 30 to 37
        Byte byteObj = b;
        Short shortObj = s;
        Integer intObj = i;
        Long longObj = l;
        Float floatObj = f;
        Double doubleObj = d;
        Character charObj = c;
        Boolean boolObj = b1;
        System.out.println("Byte object:" + byteObj);
        System.out.println("Short object:" + shortObj);
        System.out.println("Int object:" + intObj);
        System.out.println("Long object:" + longObj);
        System.out.println("Float object:" + floatObj);
        System.out.println("Double object:" + doubleObj);
        System.out.println("Character object:" + charObj);
        System.out.println("Boolean object:" + boolObj);
        //Unboxing from line 47 to 54
        byte B = byteObj;
        short S = shortObj;
        int I = intObj;
        long L = longObj;
        float F = floatObj;
        double D = doubleObj;
        char C = charObj;
        boolean B1 = boolObj;
        System.out.println();
        System.out.println("byte value:" + B);
        System.out.println("short value:" + S);
        System.out.println("int value:" + I);
        System.out.println("long value:" + L);
        System.out.println("float value:" + F);
        System.out.println("double value:" + D);
        System.out.println("character value:" + C);
        System.out.println("boolean value:" + B1);
    }
}
