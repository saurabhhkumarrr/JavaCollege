//package Java4th.Unit3;
public class StaticBlock 
{
   
    static //static block is a special block which is excuted before main method of any java program.
    {
      System.out.println("Static block is called");
    }
    public static void main(String[] args)
    {
        System.out.println("Main method is called");
    }  
}
