//package Java4th.Unit3;
/*
In Java, this keyword is a variable that refers to the current object(or holds the address of current object).
Uses of this keyword in Java:
1.this keyword can be used to refer current class's instance variable(s).
2.this can be used to invoke current class method (implicitly)
3 this() method call can be used to invoke current class's constructor.
4 this keyword can be passed as an argument in a method of a class.
5 this keyword can be passed as argument in a constructor of a class
6.this keyword can be used to return the current class's instance(object) from the method.
*/
public class ThisKeyword 
{
   int x,y;
   ThisKeyword(int x,int y) //56 78
   {
           this.x=x; // instance variable x is 56
           //tk
           this.y=y;// instance variable y is 78
   }
   int add()
   {
       return x+y;
   }
   public static void main(String[] args)
   {
       int x,y;
       java.util.Scanner sc = new java.util.Scanner(System.in);
       System.out.print("Enter first number:");
       x=sc.nextInt();
       System.out.print("Enter second number:");
       y=sc.nextInt();
       ThisKeyword tk=new ThisKeyword(x,y);// 56 78
       System.out.println("Sum of " + x + " and " + y +" is:" + tk.add());
   }
  
}
