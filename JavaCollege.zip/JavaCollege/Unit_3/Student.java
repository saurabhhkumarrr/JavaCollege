/*
1.The static keyword in Java is mainly used for memory management. 
2.We can use static keyword with variables, methods, blocks and nested classes. 
3.The static keyword applies to the class as a whole rather than 
an instance of the class.
4.this and super keywords cannot be used in a static method.
5.Static method cannot access instance variable/instance method of the class.
*/
//package Java4th.Unit3;
public class Student {
    int rollNo;
    String name;// rollNo and name are instance variables.
    static String COLLEGENAME="Guru Nanak Dev DSEU Rohini Campus";//static variable 
    public Student(int rollNo,String name)
                    // 23       "Aman"
    {
        this.rollNo=rollNo;
        //s1
        this.name=name;
        //s1
    }
    void display()// this is an instance method of Student 
    {
        
        System.out.println("Name:" + name );
        System.out.print("RollNo:" + rollNo);
    }
    static void changeName() //static method to change static variable COLLEGENAME
    {
      COLLEGENAME = "GNDIT"; 
    }
    public static void main(String[] args)
    {
        Student s1 = new Student(23,"Aman");
        s1.display();
        System.out.println();
        System.out.println(Student.COLLEGENAME);
        Student s2 = new Student(3,"Amit");
        s2.display();
        System.out.println();
        Student.changeName();
        System.out.println(Student.COLLEGENAME);
    }
    
}
