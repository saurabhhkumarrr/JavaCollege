//package java_4th_sem;
public interface Printable 
{
   void print();    
}
