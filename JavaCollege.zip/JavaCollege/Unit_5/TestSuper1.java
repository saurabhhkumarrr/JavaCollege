//package java_4th_sem;
class Dog1 extends Animal 
{
    String color = "white";
    void printColor()
    {
        System.out.println(color);
        System.out.println(super.color);
    }
    void display()
    {
        System.out.println("Eating");
        super.run();
    }
}
public class TestSuper1
{
    
    public static void main(String[] args)
    {
       Dog1 d = new Dog1();
       d.printColor();
       d.display();
    }
}
