//package java_4th_sem;
public class SuperKeyword 
{
 /*The super keyword in Java is a reference variable which refers to immediate 
   parent class object.
   Usages of super keyword in Java:
   1.super keyword can be used to refer to immediate parent class's 
   instance variable(s).
   2.super keyword can be used to call immediate parent class's method(s).
   3.super() can be used to invoke immediate parent class's constructor.
 */
}
