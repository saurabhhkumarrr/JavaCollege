//package java_4th_sem;
public class Inheritence {
/*Inheritance in Java is a mechanism in which one object acquires all the properties 
  and behaviors of a parent object.
  It is an important part of OOPs (Object Oriented programming system).
The idea behind inheritance in Java is that you can create new classes that are built upon 
existing classes. When you inherit from an existing class, 
you can reuse methods and fields(variables) of the parent class. Moreover,you can add new methods and fields in 
your current class also.
Why use inheritance in java?
For Method Overriding (so runtime polymorphism(possible with only with instance methods) can be achieved).
For Code Reusability.
Terms used in Inheritance
1.Class: A class is a group of objects which have common properties. 
It is a template or blueprint from which objects are created.
2.Sub Class/Child Class: Subclass is a class which inherits features(variables and methods) from the other class. 
It is also called a derived class, extended class, or child class.
3.Super Class/Parent Class: Superclass is the class from where a subclass inherits the features.(variables and methods)
It is also called a base class or a parent class.
4.Reusability: As the name specifies, reusability is a mechanism which facilitates you to reuse the fields 
and methods of the existing class when you create a new class
Note:In Java,a class can inherit attributes and behaviour from one class only(Single Inheritance). 
but from a class any number of classes can inherit its attributes and behaviour.
In C++,a class can inherit from multiple classes(also called Multiple Inheritance).
But this causes problems when two classes from which a child class inherits have same functions or variables.
To support multiple inheritance "in a way" in Java,Interfaces were introduced.A Java class can implement more than 1 interfaces.
*/
    
}
