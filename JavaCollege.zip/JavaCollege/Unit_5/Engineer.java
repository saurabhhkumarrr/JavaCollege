//package java_4th_sem;
public class Engineer extends Employee// extends keyword is used to create a subclass
{
    //This is an example of single inheritance.
    int bonus = 5000;
    void displayBonus()
    {
        System.out.println("Bonus is:" + this.bonus);
    }
    public static void main(String[] args)
    {
        Engineer E = new Engineer();
        E.displaySalary();
        E.displayBonus();
    }
}
/*class A
{
 int a;
}
class B extends class A
{
  int b;
}
class C extends class B
{

}
multi-level inheritance
*/

/*
  class A
  {
   int a;
  }
  class B extends A
  {
   int b;
  }
  class C extends A
  {
    int c;
  }
  hierarchical inheritance.A superclass can have any number of subclasses.
*/
