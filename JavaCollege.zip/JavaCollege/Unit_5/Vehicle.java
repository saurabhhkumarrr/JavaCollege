//package java_4th_sem;
class Vehicle 
{ 
    
    void vehicle()//instance method
    {
        System.out.println("This is the method of vehicle class");
    }
    int sum(int a,int b)//instance method.
    {
        return a+b;
    }
    void run()//instance method of this class.
    {
     System.out.println("Vehicle is running");
    }
 int speedLimit=150;//instance variable of this class.
}

