//package java_4th_sem;
public class Rectangle implements Printable,Showable 
{
    public void print()
    {
        System.out.println("Printing");
    }
    public void show()
    {
        System.out.println("Showing");
    }
    public static void main(String[] args)
    {
        Rectangle r = new Rectangle();
        r.print();
        r.show();
    }
    
    
}
