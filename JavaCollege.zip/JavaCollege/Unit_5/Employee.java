//package java_4th_sem;
public class Employee 
{
    int salary =100000;//instance variable salary
    void displaySalary()// instance 
    {
       System.out.println("Salary is:" + this.salary);//instance method displaySalary
    }
}

