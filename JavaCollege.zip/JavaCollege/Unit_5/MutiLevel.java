//Practical 9
//package practicals;
class Animal
{
    int speed ;
    void walking()
    {
        System.out.println("Walking");
    }
    void running()
    {
        System.out.println("Running");
    }
}
class Biped extends Animal
{
    void walkingWithtwoLegs()
    {
        System.out.println("Two legs animal kingdom");
    }
}
class Human extends Biped
{
    void changeSpeed(int speed)
    {
        this.speed = speed;
        System.out.println("Changing speed to:" + speed);
    }
  }
public class Mutilevel 
{
    public static void main(String[] args)
    {
        Human h = new Human();
        h.walking();
        h.running();
        h.changeSpeed(5);
        h.walkingWithtwoLegs();
    }
}
