//package java_4th_sem;
public class Interface {
/*
1.An interface in Java is a blueprint of a class. It has static constants(variables) 
and abstract methods.
2.The interface in Java is a mechanism to achieve abstraction. 
3.There can be only abstract methods in the Java interface, not method body. 
4.It is used to achieve abstraction and multiple inheritance in Java.
5.In other words,interfaces can only have abstract methods and variables. 
It cannot have a method body.
6.It cannot be instantiated just like the abstract class.
7.We can have default and static methods and private methods in an interface.
8.Interface can extend other interfaces only.
9.Interface methods do not have a body - the body is provided 
by the class implementing the interface.
10.On implementation of an interface, you must override all of its methods
11.Interface methods are by default abstract and public.
12.An interface cannot contain a constructor.(as it cannot be used to create objects).
*/
}
