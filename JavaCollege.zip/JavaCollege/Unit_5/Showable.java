//package java_4th_sem;
public interface Showable 
{
    void show();
}
