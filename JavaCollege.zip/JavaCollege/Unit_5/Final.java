//package java_4th_sem;
final public class Final
{
  /*
 The final keyword in java is used to put some restrictions in programs. 
 final keyword can be used with:
 1.variable(final variable's value cannot be changed)
 2.method(final method cannot be overriden in a subclass)
 3.class(final class cannot be extended by any other class).
 Note:A final variable that have no value it is called blank final variable or 
 uninitialized final variable.it can be initialized only via a constructor
 (if it is an instance variable).
 The blank final variable can be static also which will be initialized 
 only in the static block.
  */  
   final int SPEEDLIMIT = 100;
   public static void main(String[] args)
   {
       Final f = new Final();
       f.speedLimit = 200;
   }
}
class Final1 extends Final
{
    
}
