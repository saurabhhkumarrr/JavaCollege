//package java_4th_sem;
public class AccessModifiers {
  /*Access modifiers define level of access of variables and methods of a Java class.
  public,private,protected and default are access modifiers in Java.
  Note:Default modifier:Variables or methods declared without these 3 modifiers 
  are availabe to all classes in same package only.
   
    //Package in Java
    /*A Package in Java is a group of related classes that serve some common purpose.*/
    private int x=345;//this instance variable is only accessible in this class;
    protected int y=2323;
    public static final int HEIGHT=110;// a variable which is final is conventionally named in capital letters.
    int z=350;// default access modifier
    protected int sum(int x,int y)
    {
        return x+y;
    }
    public static void main(String[] args)
    {
        AccessModifiers access=new AccessModifiers();
        System.out.println(AccessModifiers.HEIGHT);
        System.out.println(Math.PI);
        System.out.println(access);
    }
    //Non access Modifiers:There are 2 non access modifiers;Final and Abstract
    //Protected access modifier is accessible within the package and 
     //outside of the package but through inheritance only.
}
