//package java_4th_sem;
public class Car extends Vehicle
{        
        void vehicle() //vehicle method from Vehicle class overriden here
        {
            System.out.println("This is the method of Car class.");
        }
        int sum(int a,int b) //sum method from Vehicle class overriden here
        {
          return a / b;  
        }
        void run()//instance method of this class which overrides run method from parent class.
        {
        System.out.println("Car is running");
        }
        public static void main(String[] args)
        {
            Car c = new Car();
            c.run();
            c.vehicle();
            System.out.println(c.speedLimit);
           
        }
         int speedLimit=250;
}
