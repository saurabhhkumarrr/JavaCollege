//package java_4th_sem;
class ANIMAL //helper class of Multilevel class
{
 public void eating()
 {
     System.out.println("Eating");
 }
}
class Dog extends ANIMAL //helper class of Multilevel class
{
    void barking()
    {
        System.out.println("Barking");
    }
}
class Puppy extends DOG //helper class of Multilevel class
{
    void crying()
    {
        System.out.println("Crying");
    }
}
public class Multilevel
{
    public static void main(String[] args)
    {
        Puppy p = new Puppy();
        p.eating();
        p.barking();
        p.crying();
    }
}
