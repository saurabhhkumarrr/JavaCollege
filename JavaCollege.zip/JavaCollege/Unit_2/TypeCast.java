package Java4th.Unit2;
public class TypeCast 
{
    //float f =(float) 1.234;explicit typecasting
    // increasing order of size:byte -> short -> int -> long -> float -> double  
    public static void main(String[] args)
    {
        //widening typecasting/casting down/implict typecasting
        int x = 700;
        short t = 8000;
        long y = x;
        float z = y;
        System.out.println("Value before conversion:" + x);
        System.out.println("Value after conversion:" + y);
        System.out.println("Value after conversion:" + z);
        //Narrowing typecasting/casting up/explicit typecasting
        double d = 1113132.43503580238583;
        long l =(long) d;
        int i =(int) l;
        short s = (short) i;//information loss
        System.out.println("Value before conversion:" + d);
        System.out.println("Value after conversion:" + l);
        System.out.println("Value after conversion:" + i);
        System.out.println("Value after conversion:" + s);
    }
}