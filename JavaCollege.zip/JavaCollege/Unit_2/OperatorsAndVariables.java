//package JavaCollege.Unit_2;
public class OperatorsAndVariables {
    public static void main(String[] args)
    {
        int tops; // integer variable named 'tops'.int datatype takes 32 bits.int datatype is 'signed' by default.
        float gradePointAverage = 3.14569965045F; //float variable named 'gradePointAverage'
        char key = 'c';// character variable named 'key'
        String productName = "Larvets"; // String object/variable named 'productName'
        byte escapeKey = 27; // byte variable named 'escapeKey'.byte's datatype range:-128 to 127(signed range).Signed by default
        short roomNumber = 4000;// short variable named 'roomNumber'.short datatype.It is signed by default.range:-32000 to 32000
        long salary = 264_4000_000_0000_0000L;//compiler ignores underscores in a value.Underscore character is used to make a large value more readable.long is signed by default.
        // In 8 bits=0-255(unsigned range):-128 to 127(signed range)
        boolean gameOver = false;// boolean variable takes either true or false values
        double pi = 3.1434856084056880436885468803468054880468095680648054;
        double weight = 205;
        //in terms of size:int>>>short>>>byte
        //Various types of operators in java
        System.out.println(weight);
        weight = weight + 10;//addition operator
        weight = weight - 34;  // subtraction operator
        weight = weight * 56.9;// multiplication operator
        weight = weight / 54.876; // division operator
        System.out.println(weight);
        weight = weight % 34; // remainder operator
        System.out.println(weight);
        /* int rating=50;
        rating++; // post increment operator
        System.out.println(rating);
        ++rating; // pre increment operator
        System.out.println(rating);
        rating--; // post decrement operator
        System.out.println(rating);
        --rating; // pre decrement operator
        System.out.println(rating); 
        int x = 3;
        int answer = x++ * 3; 
        System.out.println(answer);
        System.out.println(x);//4
       // answer = x++ + ++x * 3;
        System.out.println(answer);
        System.out.println(x);
        int y = 5;
        int number = ((y++) * 6) + ((4 * 10) / 2);
                     
        System.out.println(y);
        System.out.println(number);
        int n1=10,n2=20;
        System.out.println(n1&n2);// bitwise AND 01010
        //                                       10100 
        System.out.println(n1|n2);// bitiwse OR  11110
        */
    }
}